﻿using MonoTouch.Dialog;

namespace SeniorProject.DialogModels
{
    public class LoginDialogModel
    {
        public EntryElement UserName;
        public EntryElement Password;
    }
}
